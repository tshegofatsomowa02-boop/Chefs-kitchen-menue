import React, { useMemo, useState } from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

type Course = 'Starter' | 'Main Course' | 'Dessert';
type FilterCourse = 'All' | Course;

type MenuItem = {
  id: string;
  name: string;
  description: string;
  course: Course;
  price: number;
};

type FeedbackState = {
  type: 'success' | 'error' | 'info';
  message: string;
};

const courseOptions: Course[] = ['Starter', 'Main Course', 'Dessert'];

const initialMenu: MenuItem[] = [
  {
    id: '1',
    name: 'Crispy Chicken Wrap',
    description: 'Grilled chicken with lettuce, tomato and creamy garlic sauce.',
    course: 'Main Course',
    price: 32.5,
  },
  {
    id: '2',
    name: 'Berry Cheesecake',
    description: 'Smooth cheesecake topped with fresh berries and berry coulis.',
    course: 'Dessert',
    price: 18.0,
  },
  {
    id: '3',
    name: 'Pasta Salad',
    description: 'Fresh pasta tossed with vegetables, herbs, and a light vinaigrette.',
    course: 'Starter',
    price: 26.0,
  },
  {
    id: '4',
    name: 'Beef Burger',
    description: 'Juicy beef patty, cheddar, lettuce and tomato served with fries.',
    course: 'Main Course',
    price: 54.0,
  },
  {
    id: '5',
    name: 'Fruit Tart',
    description: 'Buttery pastry filled with custard and topped with seasonal fruit.',
    course: 'Dessert',
    price: 22.5,
  },
];

const emptyForm = {
  name: '',
  description: '',
  course: 'Starter' as Course,
  price: '',
};

const formatCurrency = (value: number) => `R${value.toFixed(2)}`;

export default function App() {
  const [menuItems, setMenuItems] = useState<MenuItem[]>(initialMenu);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<FilterCourse>('All');
  const [feedback, setFeedback] = useState<FeedbackState | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formError, setFormError] = useState('');

  const filteredItems = useMemo(() => {
    const normalizedSearch = searchTerm.trim().toLowerCase();

    return menuItems.filter((item) => {
      const matchesSearch =
        normalizedSearch.length === 0 ||
        item.name.toLowerCase().includes(normalizedSearch) ||
        item.description.toLowerCase().includes(normalizedSearch);

      const matchesCourse =
        selectedFilter === 'All' || item.course === selectedFilter;

      return matchesSearch && matchesCourse;
    });
  }, [menuItems, searchTerm, selectedFilter]);

  const stats = useMemo(() => {
    const totalItems = menuItems.length;
    const averagePrice =
      totalItems === 0 ? 0 : menuItems.reduce((sum, item) => sum + item.price, 0) / totalItems;
    const courseCounts = {
      Starter: menuItems.filter((item) => item.course === 'Starter').length,
      'Main Course': menuItems.filter((item) => item.course === 'Main Course').length,
      Dessert: menuItems.filter((item) => item.course === 'Dessert').length,
    };
    const highestPrice = totalItems === 0 ? 0 : Math.max(...menuItems.map((item) => item.price));
    const lowestPrice = totalItems === 0 ? 0 : Math.min(...menuItems.map((item) => item.price));

    return { totalItems, averagePrice, courseCounts, highestPrice, lowestPrice };
  }, [menuItems]);

  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
    setFormError('');
  };

  const validateForm = () => {
    if (!form.name.trim()) {
      return 'Please enter the dish name.';
    }

    if (form.name.trim().length < 2) {
      return 'Dish name must contain at least 2 characters.';
    }

    if (!form.description.trim()) {
      return 'Please add a short description.';
    }

    if (form.description.trim().length < 10) {
      return 'Description should be at least 10 characters long.';
    }

    const numericPrice = Number(form.price);
    if (!Number.isFinite(numericPrice) || numericPrice <= 0) {
      return 'Price must be a valid number greater than 0.';
    }

    return '';
  };

  const handleSubmit = () => {
    const validationMessage = validateForm();

    if (validationMessage) {
      setFormError(validationMessage);
      setFeedback({ type: 'error', message: validationMessage });
      return;
    }

    const preparedItem: MenuItem = {
      id: editingId ?? Date.now().toString(),
      name: form.name.trim(),
      description: form.description.trim(),
      course: form.course,
      price: Number(form.price),
    };

    if (editingId) {
      setMenuItems((current) =>
        current.map((item) => (item.id === editingId ? preparedItem : item)),
      );
      setFeedback({ type: 'success', message: `${preparedItem.name} updated successfully.` });
    } else {
      setMenuItems((current) => [preparedItem, ...current]);
      setFeedback({ type: 'success', message: `${preparedItem.name} added to the menu.` });
    }

    resetForm();
  };

  const handleEdit = (item: MenuItem) => {
    setEditingId(item.id);
    setForm({
      name: item.name,
      description: item.description,
      course: item.course,
      price: item.price.toString(),
    });
    setFormError('');
    setFeedback({ type: 'info', message: `Editing ${item.name}.` });
  };

  const handleDelete = (item: MenuItem) => {
    setMenuItems((current) => current.filter((menuItem) => menuItem.id !== item.id));

    if (editingId === item.id) {
      resetForm();
    }

    setFeedback({ type: 'success', message: `${item.name} was removed from the menu.` });
  };

  const feedbackStyle =
    feedback?.type === 'success'
      ? styles.successFeedback
      : feedback?.type === 'error'
        ? styles.errorFeedback
        : feedback?.type === 'info'
          ? styles.infoFeedback
          : null;

  return (
    <ScrollView style={styles.page} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Chef&apos;s Menu Manager</Text>
      <Text style={styles.subtitle}>Keep menu items organised, updated and easy to find.</Text>

      {feedback && (
        <View style={[styles.feedback, feedbackStyle]}>
          <Text style={styles.feedbackText}>{feedback.message}</Text>
        </View>
      )}

      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>Menu statistics</Text>

        <View style={styles.statsGrid}>
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{stats.totalItems}</Text>
            <Text style={styles.statLabel}>Items</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{formatCurrency(stats.averagePrice)}</Text>
            <Text style={styles.statLabel}>Average</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{stats.courseCounts.Starter}</Text>
            <Text style={styles.statLabel}>Starters</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{stats.courseCounts['Main Course']}</Text>
            <Text style={styles.statLabel}>Mains</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{stats.courseCounts.Dessert}</Text>
            <Text style={styles.statLabel}>Desserts</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{formatCurrency(stats.highestPrice)}</Text>
            <Text style={styles.statLabel}>Highest</Text>
          </View>
        </View>
      </View>

      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>Search and filter</Text>

        <TextInput
          style={styles.input}
          placeholder="Search by name or description"
          placeholderTextColor="#7d685d"
          value={searchTerm}
          onChangeText={setSearchTerm}
        />

        <Text style={styles.fieldLabel}>Filter by course</Text>
        <View style={styles.filterRow}>
          {(['All', ...courseOptions] as FilterCourse[]).map((course) => (
            <Pressable
              key={course}
              style={[
                styles.filterButton,
                selectedFilter === course && styles.filterButtonActive,
              ]}
              onPress={() => setSelectedFilter(course)}
            >
              <Text
                style={[
                  styles.filterButtonText,
                  selectedFilter === course && styles.filterButtonTextActive,
                ]}
              >
                {course}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>{editingId ? 'Edit menu item' : 'Add new menu item'}</Text>

        <Text style={styles.fieldLabel}>Dish name</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. Mushroom Risotto"
          placeholderTextColor="#7d685d"
          value={form.name}
          onChangeText={(value) => setForm((current) => ({ ...current, name: value }))}
        />

        <Text style={styles.fieldLabel}>Description</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="Describe the dish"
          placeholderTextColor="#7d685d"
          multiline
          numberOfLines={3}
          value={form.description}
          onChangeText={(value) => setForm((current) => ({ ...current, description: value }))}
        />

        <Text style={styles.fieldLabel}>Price</Text>
        <TextInput
          style={styles.input}
          placeholder="0.00"
          placeholderTextColor="#7d685d"
          keyboardType="decimal-pad"
          value={form.price}
          onChangeText={(value) => setForm((current) => ({ ...current, price: value }))}
        />

        <Text style={styles.fieldLabel}>Course</Text>
        <View style={styles.courseRow}>
          {courseOptions.map((course) => (
            <Pressable
              key={course}
              style={[
                styles.courseButton,
                form.course === course && styles.courseButtonActive,
              ]}
              onPress={() => setForm((current) => ({ ...current, course }))}
            >
              <Text
                style={[
                  styles.courseButtonText,
                  form.course === course && styles.courseButtonTextActive,
                ]}
              >
                {course}
              </Text>
            </Pressable>
          ))}
        </View>

        {formError ? <Text style={styles.errorText}>{formError}</Text> : null}

        <View style={styles.actionRow}>
          <Pressable style={styles.primaryButton} onPress={handleSubmit}>
            <Text style={styles.primaryButtonText}>{editingId ? 'Update item' : 'Save item'}</Text>
          </Pressable>

          {editingId && (
            <Pressable style={styles.secondaryButton} onPress={resetForm}>
              <Text style={styles.secondaryButtonText}>Cancel</Text>
            </Pressable>
          )}
        </View>
      </View>

      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>All menu items</Text>

        {filteredItems.length === 0 ? (
          <Text style={styles.emptyState}>No menu items match your current search or filter.</Text>
        ) : (
          filteredItems.map((item) => (
            <View key={item.id} style={styles.menuItemCard}>
              <View style={styles.menuItemHeader}>
                <View style={styles.menuItemTitles}>
                  <Text style={styles.itemName}>{item.name}</Text>
                  <Text style={styles.coursePill}>{item.course}</Text>
                </View>
                <Text style={styles.itemPrice}>{formatCurrency(item.price)}</Text>
              </View>

              <Text style={styles.itemDescription}>{item.description}</Text>

              <View style={styles.itemActions}>
                <Pressable style={styles.smallButton} onPress={() => handleEdit(item)}>
                  <Text style={styles.smallButtonText}>Edit</Text>
                </Pressable>
                <Pressable
                  style={[styles.smallButton, styles.deleteButton]}
                  onPress={() => handleDelete(item)}
                >
                  <Text style={styles.smallButtonText}>Delete</Text>
                </Pressable>
              </View>
            </View>
          ))
        )}
      </View>
    </ScrollView>
  );
}

const mainColour = '#5a4634';
const softBackground = '#f2e3c5';
const panelBackground = '#f8f1e5';
const borderColour = '#d2b58a';
const textColour = '#201a17';
const mutedText = '#67584d';
const successColour = '#dff3e3';
const successText = '#1f5d3a';
const errorColour = '#f8d9d9';
const errorText = '#8b2f2f';
const infoColour = '#e5edf9';
const infoText = '#355a91';

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: '#d8c4a3',
  },
  content: {
    padding: 20,
    paddingBottom: 40,
  },
  title: {
    fontSize: 30,
    fontWeight: '800',
    color: textColour,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 15,
    color: mutedText,
    marginBottom: 18,
  },
  sectionCard: {
    backgroundColor: panelBackground,
    borderRadius: 14,
    padding: 16,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: borderColour,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: textColour,
    marginBottom: 12,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statBox: {
    width: '31%',
    backgroundColor: '#f5e9d5',
    padding: 12,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#d9b889',
  },
  statValue: {
    fontSize: 16,
    fontWeight: '800',
    color: textColour,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 11,
    color: mutedText,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  fieldLabel: {
    color: textColour,
    fontWeight: '700',
    marginTop: 10,
    marginBottom: 6,
  },
  input: {
    backgroundColor: '#fffdf9',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#c8ab7e',
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: textColour,
    fontSize: 15,
  },
  textArea: {
    minHeight: 88,
    textAlignVertical: 'top',
  },
  filterRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
  },
  filterButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f0dfbf',
    borderWidth: 1,
    borderColor: '#c79a61',
    marginRight: 8,
    marginBottom: 8,
  },
  filterButtonActive: {
    backgroundColor: mainColour,
    borderColor: mainColour,
  },
  filterButtonText: {
    color: textColour,
    fontWeight: '600',
  },
  filterButtonTextActive: {
    color: '#fff',
  },
  courseRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 6,
  },
  courseButton: {
    backgroundColor: '#f7eedf',
    borderWidth: 1,
    borderColor: '#ceb188',
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 16,
    marginRight: 8,
    marginBottom: 8,
  },
  courseButtonActive: {
    backgroundColor: '#ead8b5',
    borderColor: '#a77e4a',
  },
  courseButtonText: {
    color: textColour,
    fontWeight: '600',
  },
  courseButtonTextActive: {
    color: '#2a1f16',
  },
  actionRow: {
    flexDirection: 'row',
    marginTop: 18,
    gap: 10,
  },
  primaryButton: {
    flex: 1,
    backgroundColor: mainColour,
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 15,
  },
  secondaryButton: {
    paddingHorizontal: 18,
    borderRadius: 10,
    backgroundColor: '#e9d9b2',
    justifyContent: 'center',
  },
  secondaryButtonText: {
    color: textColour,
    fontWeight: '700',
  },
  errorText: {
    color: errorText,
    marginTop: 10,
    fontWeight: '600',
  },
  feedback: {
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    marginBottom: 16,
  },
  successFeedback: {
    backgroundColor: successColour,
    borderColor: '#a7d0af',
  },
  errorFeedback: {
    backgroundColor: errorColour,
    borderColor: '#d6a0a0',
  },
  infoFeedback: {
    backgroundColor: infoColour,
    borderColor: '#a7bfe0',
  },
  feedbackText: {
    color: textColour,
    fontWeight: '600',
  },
  menuItemCard: {
    backgroundColor: '#fffaf2',
    borderWidth: 1,
    borderColor: '#d7c09c',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
  },
  menuItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  menuItemTitles: {
    flex: 1,
    marginRight: 10,
  },
  itemName: {
    fontSize: 18,
    fontWeight: '800',
    color: textColour,
    marginBottom: 6,
  },
  coursePill: {
    backgroundColor: '#e9d5b4',
    color: textColour,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    alignSelf: 'flex-start',
    fontSize: 11,
    fontWeight: '700',
  },
  itemPrice: {
    fontWeight: '800',
    fontSize: 16,
    color: textColour,
  },
  itemDescription: {
    color: mutedText,
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 12,
  },
  itemActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 8,
  },
  smallButton: {
    backgroundColor: '#e2d1af',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#c9a370',
  },
  smallButtonText: {
    color: textColour,
    fontWeight: '700',
  },
  deleteButton: {
    backgroundColor: '#f0d9d9',
    borderColor: '#c98787',
  },
  emptyState: {
    padding: 18,
    borderRadius: 10,
    backgroundColor: '#f2e6cf',
    color: mutedText,
    textAlign: 'center',
    fontWeight: '600',
  },
});
